﻿using System;
using WildFarm.Core;
using WildFarm.Models.Animals.Mammal.Feline;

namespace WildFarm
{
    public class StarUp
    {
        static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
