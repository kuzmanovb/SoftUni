﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftJail.Data.Models.Enums
{
    public enum Weapon
    {
        Knife = 1, 
        FlashPulse = 2, 
        ChainRifle = 3, 
        Pistol = 4, 
        Sniper = 5
    }
}
