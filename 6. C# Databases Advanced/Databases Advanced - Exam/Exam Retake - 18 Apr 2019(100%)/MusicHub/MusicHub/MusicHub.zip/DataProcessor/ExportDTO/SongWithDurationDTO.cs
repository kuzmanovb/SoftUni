﻿
using System.Xml.Serialization;

namespace MusicHub.DataProcessor.ExportDTO
{
    [XmlType("Song")]
    public class SongWithDurationDTO
    {
        [XmlElement("SongName")]
        public string SongName { get; set; }

        [XmlElement("Writer")]
        public string Writer { get; set; }

        [XmlElement("Performer")]
        public string Performer { get; set; }

        [XmlElement("AlbumProducer")]
        public string AlbumProducer { get; set; }

        [XmlElement("Duration")]
        public string Duration { get; set; }
    }
}
